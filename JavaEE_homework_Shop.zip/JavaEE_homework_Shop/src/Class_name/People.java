package Class_name;

public class People {
    private String name;
    private String type;
    private String live_able;
    private String attack_able;
    private String skill;
    private String start_difficult;
    private String img;
    private String price;

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }


    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLive_able() {
        return live_able;
    }

    public void setLive_able(String live_able) {
        this.live_able = live_able;
    }

    public String getAttack_able() {
        return attack_able;
    }

    public void setAttack_able(String attack_able) {
        this.attack_able = attack_able;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public String getStart_difficult() {
        return start_difficult;
    }

    public void setStart_difficult(String start_difficult) {
        this.start_difficult = start_difficult;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
